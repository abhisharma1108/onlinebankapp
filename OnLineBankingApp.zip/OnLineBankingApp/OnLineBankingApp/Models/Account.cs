﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;


namespace OnLineBankingApp.Models
{
  

    
    public class Account
    {

        [Required, Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Display(Name = "AccountId")]
        public int AccountId{ get; set; }

        [ForeignKey("CustomerID")]
        public int CustomerID { get; set; }

        [ForeignKey("AccTypeId")]
        public int? AccTypeId { get; set; }

        //[Required]
        //[Display(Name = "Type")]
        //public char AccountType { get; set; }


        [Required]
        [Display(Name = "Current Balance")]
        public decimal Balance { get; set; }

        [Required]
        [Display(Name = "Date of Opening")]
        public DateTime DateOfOpening { get; set; }


        //[Required]
        //[Display(Name ="Cheque Book Status")]  
        //public ChequeBook ChequeBookAlloted { get; set; }


        
        public virtual Customer Customer { get; set; }
        public virtual AccountType AccountType { get; set; }

        public virtual ICollection<ChequeBook> ChequeBooks { get; set; }

        public virtual ICollection<Transaction> Transactions { get; set; }



    }
}
