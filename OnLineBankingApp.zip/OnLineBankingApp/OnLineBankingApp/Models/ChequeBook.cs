﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace OnLineBankingApp.Models
{
    public class ChequeBook
    {

        [Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int ChqId { get; set; }

        [ForeignKey("AccountId")]
        public int AccountId { get; set; }

        [DisplayName("ChequeBook Status")]
        [Required(ErrorMessage = "ChequeBook Status  should not be blank")]

        [ForeignKey("StatusID")]
        public int StatusID { get; set; }

        public virtual Account Account { get; set; }

        public virtual Status Status { get; set; }



    }
}
